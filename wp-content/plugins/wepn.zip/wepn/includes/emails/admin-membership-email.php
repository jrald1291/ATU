<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Become a member</title>
</head>
<body>
    <div>
        <p>Hi Admin,</p>
        <p>New membership <a href="mailto:<?php echo $data['email']; ?>"><?php echo $data['email']; ?></a></p>
        <p>Thank,</p>
    </div>
</body>
</html>