jQuery(document).ready(function ($) {
    /*
	$('.cbratingsystem-admin-dashborad .handlediv').bind('click.postboxes', function () {
		var p = $(this).parent('.postbox'), id = p.attr('id');

		p.toggleClass('closed');
	});
    */
});