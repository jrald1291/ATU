jQuery(document).ready(function ($) {


    //jquery choosen
    //$('#edit-post-type').chosen();

    $('.cbratingf_chosen').chosen();

	//$('#edit-allowed-users').chosen();
	//$('#edit-editor-group').chosen();
    //$('#edit-view-allowed-users').chosen();
	//$('#edit-comment-view-allowed-users').chosen();
    //$('#edit-comment-moderation-users').chosen();



    /*
    var elems = ['.cbrp-form-listing', '.cb-ratingForm-edit', '.cbrp-log-report', '.cbrp-log-report-average', '.cbratingsystem-theme-settings', '.cbrp_front_content'];

    for (i in elems) {
		//$(elems[i] + ' input[type="checkbox"], input[type="radio"]').uniform();


		$(elems[i] + ' select.question_field_type, ' + elems[i] + ' .select_count').selectize({
			create   : true,
			sortField: 'text'
		});

	}
    */
});